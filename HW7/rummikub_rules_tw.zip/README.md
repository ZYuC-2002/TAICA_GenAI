# 拉密 (Rummikub) RAG 格式化資料集

此資料集將拉密規則摘要整理為符合特定 Metadata 格式的文本，並包含對應的 CSV 檢索問題集。

## 檔案結構
- `01_intro_and_setup.txt`: 遊戲介紹與設置
- `02_gameplay_rules.txt`: 回合流程與破冰規則
- `03_manipulation.txt`: 牌組拆解與重組技巧
- `04_joker_and_scoring.txt`: 百搭牌規則與結算計分
- `05_question_bank.csv`: RAG 檢索練習問題集 (CSV 格式)
- `sources.csv`: 來源對照
